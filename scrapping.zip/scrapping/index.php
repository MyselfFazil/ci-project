<?php
ini_set('max_execution_time', 0);
include_once('simple_html_dom.php');

function scraping_generic($url, $search, $attribute, $check = FALSE) {
	// Didn't find it yet.
	$counter = 0;
	$return = false;

	echo "reading the url: " . $url . "<br/>";
    // create HTML DOM
    $html = file_get_html($url);
	echo "url has been read.<br/>";

    // get article block
/*     foreach($html->find($search) as $found) {
		// Found at least one.
		$return = true;
		echo "found a: " . $search . "<br/><pre>";
		$found->dump();
		echo "</pre><br/>";
	} */

	foreach($html->find($search) as $image){
		$imageSrc = $image->$attribute;
		$imageUri = rel2abs($imageSrc, $url);
		$extension = pathinfo(parse_url($imageUri, PHP_URL_PATH), PATHINFO_EXTENSION);
		if($extension){
			$counter += 1;
		}
	}
	
	echo "Files count:- ".$counter."<br>";

	if( $check == TRUE ){
		foreach( $html->find($search) as $image )
		{
		$imageSrc = $image->$attribute;
		$imageUri = rel2abs($imageSrc, $url);
		$extension = pathinfo(parse_url($imageUri, PHP_URL_PATH), PATHINFO_EXTENSION);
		$filename  = pathinfo(parse_url($imageUri, PHP_URL_PATH), PATHINFO_FILENAME);
		if (!file_exists(__DIR__."/downloads")) {
			mkdir(__DIR__."/downloads", 0777, true);
		}

		if( $extension ){
		$imageLocalPath = __DIR__.'/downloads'.'/'.preg_replace('/[^a-z0-9-.]/i', '-', $filename.".".$extension);
			if (!file_exists($imageLocalPath))
			{
				$imageData = file_get_contents($imageUri, false);
				file_put_contents($imageLocalPath, $imageData);
			}
			else
				$imageData = file_get_contents($imageLocalPath);
			}
		}
	}
    
    // clean up memory
    $html->clear();
    unset($html);

    return $return;
}

function rel2abs($rel, $base)
{
	/* return if already absolute URL */
	if (parse_url($rel, PHP_URL_SCHEME) != '' || substr($rel, 0, 2) == '//') return $rel;

	/* queries and anchors */
	if ($rel[0]=='#' || $rel[0]=='?') return $base.$rel;

	/* parse base URL and convert to local variables:
	 $scheme, $host, $path */
	extract(parse_url($base));

	/* remove non-directory element from path */
	$path = preg_replace('#/[^/]*$#', '', $path);

	/* destroy path if relative url points to root */
	if ($rel[0] == '/') $path = '';

	/* dirty absolute URL */
	$abs = "$host$path/$rel";

	/* replace '//' or '/./' or '/foo/../' with '/' */
	$re = array('#(/\.?/)#', '#/(?!\.\.)[^/]+/\.\./#');
	for($n=1; $n>0; $abs=preg_replace($re, '/', $abs, -1, $n)) {}

	/* absolute URL is ready! */
	return $scheme.'://'.$abs;
}

?>
<?php
// ------------------------------------------
error_log ("post:" . print_r($_POST, true));
$url = "";
if (isset($_POST['url']))
{
	$url = $_POST['url'];
}
$search = "";
if (isset($_POST['search']))
{
	$search = $_POST['search'];
}

$attribute = "";
if (isset($_POST['attribute']))
{
	$attribute = $_POST['attribute'];
}

?>

<form method="post">
	URL: <input name="url" type="text" value="<?=$url;?>"/><br/>
	Element: <input name="search" type="text" value="<?=$search;?>"/><br/>
	Attribute: <input name="attribute" type="text" value="<?=$attribute;?>"/><br/>
	<input name="check" type="submit" value="check"/>
	<input name="submit" type="submit" value="Submit"/>
</form>


<?php

if (!file_exists(__DIR__."/downloads")) {
	mkdir(__DIR__."/downloads", 0777, true);
}

if (isset ($_POST['submit']))
{
	if( empty($_POST['url']) )
	{
		die("Please enter all details");
	}
	else
	{
		$response = scraping_generic($_POST['url'], $_POST['search'], $_POST['attribute'], TRUE);
		if (!$response)
		{
			//echo "Did not find any: " . $_POST['search'] . "<br />";
		}
	}	
}

if (isset ($_POST['check']))
{
	if( empty($_POST['url']) )
	{
		die("Please enter all details");
	}
	else
	{
		$response = scraping_generic($_POST['url'], $_POST['search'], $_POST['attribute']);
		if (!$response)
		{
			//echo "Did not find any: " . $_POST['search'] . "<br />";
		}
	}

}

?>